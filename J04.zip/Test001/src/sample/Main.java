package sample;

import java.util.HashMap;
import java.util.Map;
import javafx.application.Platform;
import java.util.Scanner;
import java.util.UUID;

public class Main {

    static HashMap<Integer, String> Map = new HashMap<Integer, String>();

    public static void main(String[] args) throws Exception {

        Scanner vstup = new Scanner(System.in);
        UUID uuid_1 = UUID.randomUUID();

        System.out.println("(A)dd; (E)dit; (D)elete; (S)earch; (L)ist; (Q)uit");

        int Num_Person = 1;
        int x1 = 0;


        Map.put(Num_Person, "Martin " + "Palkovič");
        Num_Person++;
        Map.put(Num_Person, "Denisa " + "Vlastná");
        Num_Person++;
        Map.put(Num_Person, "Kristína " + "Burcelová");
        Num_Person++;
        Map.put(Num_Person, "Igor " + "Ivanovič");
        Num_Person++;
        Map.put(Num_Person, "Adriana " + "Šimková");
        Num_Person++;

        while (x1!=1){

        String vst1 = vstup.nextLine();
        if(vst1.equals("A"))
        {
        System.out.print("Add Name: ");
        String zmena = vstup.nextLine();
        Map.put(Num_Person, zmena);
        Num_Person++;
        System.out.println("Added.");


        System.out.println("(A)dd; (E)dit; (D)elete; (S)earch; (L)ist; (Q)uit");

        }

        if(vst1.equals("E"))
        {
        Scanner uprava = new Scanner (System.in);
        for (Map.Entry me : Map.entrySet())
        {
        System.out.println(me.getKey() + "." + " " + me.getValue());
        }
        System.out.println("Change Number: ");
        int zmena1 = vstup.nextInt();
        System.out.println("New name: ");
        String zmena2 = uprava.nextLine();
        Map.replace(zmena1, zmena2);
        System.out.println("Changed.");


        System.out.println("(A)dd; (E)dit; (D)elete; (S)earch; (L)ist; (Q)uit");

        }

        if(vst1.equals("D"))
        {
        for (Map.Entry me : Map.entrySet())
        {
        System.out.println(me.getKey() + "." + " " +  me.getValue());
        }
        System.out.print("Delete Number: ");
        int zmena = vstup.nextInt();
        Map.remove(zmena);
        System.out.println("Deleted.");

        System.out.println("(A)dd; (E)dit; (D)elete; (S)earch; (L)ist; (Q)uit");

        }

        if(vst1.equals("S"))
        {
        System.out.println("Search name: ");
        String x = vstup.nextLine();
        if(Map.containsValue(x))
        {
        System.out.println("Found.");
        }
        else
        {
        System.out.println("Not Found.");
        }

        System.out.println("(A)dd; (E)dit; (D)elete; (S)earch; (L)ist; (Q)uit");

        }

        if(vst1.equals("L"))
        {
        for (Map.Entry me : Map.entrySet())
        {
        System.out.println(me.getKey() + "." + " " + me.getValue());
        }

        System.out.println("(A)dd; (E)dit; (D)elete; (S)earch; (L)ist; (Q)uit");

        }

        if(vst1.equals("Q"))
        {
        x1 = 1;
        Platform.exit();
        }
        }
        }
        }