package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.HashMap;
import java.util.UUID;
public class Main extends Application {


    @Override
    public void start(Stage primaryStage) throws Exception{

        Parent root = FXMLLoader.load(getClass().getResource("TableView.fxml"));
        primaryStage.setTitle("Address Book UKF");
        primaryStage.setScene(new Scene(root, 800, 605));
        primaryStage.show();
    }
//J04?

    public static void main(String[] args) {
        launch(args);
    }
}
