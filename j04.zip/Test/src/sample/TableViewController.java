package AddressBook;

import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.scene.control.TableCell;
import javafx.scene.control.Cell.*;
import javafx.scene.control.TableColumn;

public class TableViewController {
    @FXML private TableView<Student> tableView;
    @FXML private TextField firstNameField;
    @FXML private TextField lastNameField;
    @FXML private TextField emailField;
    @FXML private AddressBook.Student student;
    @FXML
    protected void addStudent(ActionEvent event) {
        AddressBook.Student student1 = new AddressBook.Student(
                firstNameField.getText(),
                lastNameField.getText(),
                emailField.getText());
        ObservableList<Student> data = tableView.getItems();
        data.add(student1);
        firstNameField.setText("");
        lastNameField.setText("");
        emailField.setText("");
        student = student1;
    }

    @FXML
    protected void quitApp(ActionEvent event) {
        Platform.exit();
    };

    @FXML
    protected void editStudent(ActionEvent event) {
        ObservableList<Student> data = tableView.getItems();
        data.remove(student);
        AddressBook.Student student1 = new AddressBook.Student(
                firstNameField.getText(),
                lastNameField.getText(),
                emailField.getText());
        ObservableList<Student> data2 = tableView.getItems();
        data2.add(student1);
        firstNameField.setText("");
        lastNameField.setText("");
        emailField.setText("");
        student = student1;


    };

    @FXML
    protected void searchStudent(ActionEvent event) {
        AddressBook.Student student1 = new AddressBook.Student(
                firstNameField.getText(),
                lastNameField.getText(),
                emailField.getText());
        ObservableList<Student> data = tableView.getItems();
        for (int i = 0; i < data.size(); i++)
        {
            if (student1.equals(data.get(i)))
            {
                System.out.println(student1);
                break;
            }
        }

        firstNameField.setText("");
        lastNameField.setText("");
        emailField.setText("");
        student = student1;



    };

    @FXML
    protected void listStudent(ActionEvent event) {
        AddressBook.Student student1 = new AddressBook.Student(
                firstNameField.getText(),
                lastNameField.getText(),
                emailField.getText());
        ObservableList<Student> data = tableView.getItems();
        System.out.println(student1);
        firstNameField.setText("");
        lastNameField.setText("");
        emailField.setText("");
        student = student1;
    };

    @FXML
    protected void removeStudent(ActionEvent event) {
        ObservableList<Student> data = tableView.getItems();
        data.remove(student);
    };

    }

