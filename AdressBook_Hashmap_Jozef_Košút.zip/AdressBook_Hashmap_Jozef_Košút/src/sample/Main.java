package sample;

import java.util.HashMap;
import java.util.Scanner;
import java.util.UUID;

public class Main{
    public static void main(String[] args) {
        Scanner vstup = new Scanner(System.in);

        HashMap<String, String> Osoby = new HashMap<String, String>();

        System.out.println(" ");
        System.out.println(" ");
        System.out.println("  Address Book");
        System.out.println(" ");
        System.out.println("A je add (Pridat do zoznamu).");
        System.out.println("L je list (Zobrazit cely zoznam).");
        System.out.println("Q je quit (Vypnut program).");
        System.out.println("S je search (Hladat osobu v zozname).");
        System.out.println("E je edit (Upravit osobu).");
        System.out.println("D je delet (Vymazat osobu).");
        System.out.println("M je deletmap (Vymazat cely zoznam).");
        System.out.println(" ");

        UUID uuid = UUID.randomUUID();
        UUID uuid2 = UUID.randomUUID();
        UUID uuid3 = UUID.randomUUID();
        UUID uuid4 = UUID.randomUUID();
        UUID uuid5 = UUID.randomUUID();
        UUID uuid6 = UUID.randomUUID();
        UUID uuid7 = UUID.randomUUID();
        UUID uuid8 = UUID.randomUUID();
        UUID uuid9 = UUID.randomUUID();
        String randomUUIDString =  uuid.toString();
        String randomUUIDString2 =  uuid2.toString();
        String randomUUIDString3 =  uuid3.toString();
        String randomUUIDString4 =  uuid4.toString();
        String randomUUIDString5 =  uuid5.toString();
        String randomUUIDString6 =  uuid6.toString();
        String randomUUIDString7 =  uuid7.toString();
        String randomUUIDString8 =  uuid8.toString();
        String randomUUIDString9 =  uuid9.toString();
        Osoby.put(randomUUIDString, "Pato Skolnik");
        Osoby.put(randomUUIDString2, "Richard Svec");
        Osoby.put(randomUUIDString3, "Jan Haluz");
        Osoby.put(randomUUIDString4, "Katarina Frajkova");
        Osoby.put(randomUUIDString5, "Zuzana Kvasajova");
        Osoby.put(randomUUIDString6, "Lucia Rajtarova");
        Osoby.put(randomUUIDString7, "Nikola Chrenkova");
        Osoby.put(randomUUIDString8, "Erik Jancek");
        Osoby.put(randomUUIDString9, "Jozef Kosut");

        for(int j = 0; j < 100; j++){
            String odpoved1 = vstup.nextLine();


            if(odpoved1.equals("A")) {
                UUID uuid10 = UUID.randomUUID();
                System.out.println("UUID je hotove.");
                String randomUUIDString10 =  uuid10.toString();
                System.out.println("Teraz zadajte meno + priezvisko: ");
                String name = vstup.nextLine();
                Osoby.put(randomUUIDString10, name);
                System.out.println("Osoba je pridana.");
            }

            if(odpoved1.equals("L")) {
                System.out.println(Osoby.size()+" su registrovany v zozname.");
                for (String i : Osoby.keySet()) {
                    System.out.println("UUID: " + i + " Meno: " + Osoby.get(i));
                }
            }

            if(odpoved1.equals("Q")) {
                System.exit(0);
            }

            if(odpoved1.equals("S")) {
                System.out.println("Zadajte UUID hladaneho: ");
                String uuidhladaneho = vstup.nextLine();
                int najdeny = 1;
                for(String hladany : Osoby.keySet()){
                    if(hladany.equals(uuidhladaneho)){najdeny++;}
                }
                if(najdeny==2){System.out.println(uuidhladaneho+" je v zozname.");}
                else {System.out.println(uuidhladaneho+" nieje v zozname.");}

            }

            if(odpoved1.equals("E")) {
                System.out.println("Zadajte UUID toho koho chcete zmenit: ");
                String uuidzmeneneho = vstup.nextLine();
                int najdeny = 1;
                for(String hladany : Osoby.keySet()){
                    if(hladany.equals(uuidzmeneneho)){najdeny++;}
                }
                if(najdeny==2){
                    UUID uuid13 = UUID.randomUUID();
                    String randomUUIDString13 =  uuid13.toString();
                    System.out.println("Je v zozname.");
                    Osoby.remove(uuidzmeneneho);
                    System.out.println("Bolo mu pridane nove UUID.");
                    System.out.println("Teraz zadajte nove meno: ");
                    String meno = vstup.nextLine();
                    Osoby.put(randomUUIDString13, meno);
                }
                else {System.out.println(uuidzmeneneho+" nieje v zozname.");}
            }

            if(odpoved1.equals("D")) {
                System.out.println("Zadajte UUID toho koho chcete vymazat: ");
                String uuidvymazaneho = vstup.nextLine();
                int najdeny = 1;
                for(String hladany : Osoby.keySet()){
                    if(hladany.equals(uuidvymazaneho)){najdeny++;}
                }
                if(najdeny==2){
                    Osoby.remove(uuidvymazaneho);
                    System.out.println(uuid2+" je vymazany.");
                }
                else {System.out.println("Nieje v zozname.");}
            }

            if(odpoved1.equals("M")) {
                System.out.println("Chcete cely zoznam vymazat? Y/N");
                String odpoved = vstup.nextLine();
                if(odpoved.equals("Y")){Osoby.clear();System.out.println("Zoznam bol vymazany!");}
                if(odpoved.equals("N")){System.out.println("Zoznam nebol vymazany!");}
            }
        }


    }
}